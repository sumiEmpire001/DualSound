package com.example.dualsound

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private val PageBg = Color(0xFF0B0D14)
private val PanelBg = Color(0xFF171B28)
private val Accent = Color(0xFF9D8CFF)
private val SecondaryText = Color(0xFFA9AEC1)

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, android.content.ComponentName(this, MusicPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                if (future.isDone && !future.isCancelled) {
                    runCatching { mediaController = future.get() }
                }
            }, ContextCompat.getMainExecutor(this))
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Accent,
                background = PageBg,
                surface = PanelBg,
                onBackground = Color.White,
                onSurface = Color.White
            )) {
                DualSoundScreen(
                    context = this,
                    getController = { mediaController }
                )
            }
        }
    }

    override fun onDestroy() {
        controllerFuture?.let(MediaController::releaseFuture)
        controllerFuture = null
        mediaController = null
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun DualSoundScreen(
    context: Context,
    getController: () -> MediaController?
) {
    var controller by remember { mutableStateOf(getController()) }
    var title by remember { mutableStateOf("Choose a song to begin") }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var bluetoothConnected by remember { mutableStateOf(checkBluetoothOutput(context)) }
    var trackCount by remember { mutableStateOf(0) }

    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        val player = getController()
        if (uris.isNotEmpty() && player != null) {
            val items = uris.map { uri ->
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                MediaItem.Builder()
                    .setUri(uri)
                    .setMediaMetadata(
                        androidx.media3.common.MediaMetadata.Builder()
                            .setTitle(fileTitle(context, uri))
                            .build()
                    )
                    .build()
            }
            player.setMediaItems(items)
            player.prepare()
            player.play()
            trackCount = items.size
            title = items.firstOrNull()?.mediaMetadata?.title?.toString() ?: "Selected audio"
        }
    }

    DisposableEffect(Unit) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
                bluetoothConnected = checkBluetoothOutput(context)
            }
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
                bluetoothConnected = checkBluetoothOutput(context)
            }
        }
        audioManager.registerAudioDeviceCallback(callback, null)
        onDispose { audioManager.unregisterAudioDeviceCallback(callback) }
    }

    LaunchedEffect(Unit) {
        while (isActive) {
            controller = getController()
            val player = getController()
            if (player != null) {
                isPlaying = player.isPlaying
                position = player.currentPosition.coerceAtLeast(0L)
                duration = player.duration.takeIf { it > 0 } ?: 0L
                title = player.currentMediaItem?.mediaMetadata?.title?.toString() ?: title
            }
            bluetoothConnected = checkBluetoothOutput(context)
            delay(450)
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = PageBg) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF19152E), PageBg, PageBg)))
                .padding(horizontal = 22.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(Accent.copy(alpha = 0.18f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Accent, modifier = Modifier.size(28.dp))
                }
                Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                    Text("DualSound", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Your music. Your space.", color = SecondaryText, fontSize = 13.sp)
                }
                IconButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Default.FolderOpen, contentDescription = "Choose music", tint = Color.White)
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = PanelBg)
            ) {
                Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .background(
                                Brush.linearGradient(listOf(Color(0xFF51428D), Color(0xFF25213E), Color(0xFF191D2B))),
                                RoundedCornerShape(22.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.GraphicEq, contentDescription = "Music artwork", tint = Accent, modifier = Modifier.size(84.dp))
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(
                            title,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(if (trackCount > 0) "$trackCount track(s) in current selection" else "Local music library", color = SecondaryText, fontSize = 13.sp)
                    }
                    Slider(
                        value = if (duration > 0) position.coerceIn(0L, duration).toFloat() else 0f,
                        onValueChange = { position = it.toLong() },
                        onValueChangeFinished = { getController()?.seekTo(position) },
                        valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                        enabled = duration > 0,
                        colors = androidx.compose.material3.SliderDefaults.colors(
                            thumbColor = Accent,
                            activeTrackColor = Accent,
                            inactiveTrackColor = Color(0xFF3B3F50)
                        )
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(formatTime(position), color = SecondaryText, fontSize = 12.sp)
                        Text("-${formatTime((duration - position).coerceAtLeast(0L))}", color = SecondaryText, fontSize = 12.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { getController()?.seekToPreviousMediaItem() }, enabled = getController()?.hasPreviousMediaItem() == true) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                        IconButton(
                            onClick = {
                                getController()?.let { player ->
                                    if (player.isPlaying) player.pause() else player.play()
                                }
                            },
                            modifier = Modifier
                                .size(66.dp)
                                .background(Accent, CircleShape)
                        ) {
                            Icon(
                                if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause" else "Play",
                                tint = Color(0xFF151224),
                                modifier = Modifier.size(38.dp)
                            )
                        }
                        IconButton(onClick = { getController()?.seekToNextMediaItem() }, enabled = getController()?.hasNextMediaItem() == true) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(34.dp))
                        }
                    }
                    Button(
                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF29243F))
                    ) {
                        Icon(Icons.Default.FolderOpen, contentDescription = null)
                        Spacer(Modifier.size(9.dp))
                        Text("Choose music from phone")
                    }
                }
            }

            Text("AUDIO OUTPUT", color = SecondaryText, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PanelBg)
            ) {
                Column(modifier = Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(42.dp).background(Color(0xFF252B3B), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(if (bluetoothConnected) Icons.Default.BluetoothConnected else Icons.Default.BluetoothDisabled,
                                contentDescription = null, tint = if (bluetoothConnected) Accent else SecondaryText)
                        }
                        Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                            Text("Bluetooth sound system", fontWeight = FontWeight.SemiBold, color = Color.White)
                            Text(if (bluetoothConnected) "Bluetooth audio output detected" else "No Bluetooth audio output detected", color = SecondaryText, fontSize = 12.sp)
                        }
                        Box(modifier = Modifier.size(8.dp).background(if (bluetoothConnected) Color(0xFF55D6A2) else Color(0xFF777B8D), CircleShape))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Speaker, contentDescription = null, tint = SecondaryText)
                        Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                            Text("Video audio on phone", color = Color.White, fontWeight = FontWeight.Medium)
                            Text("Requires Android / device audio separation support", color = SecondaryText, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.StopCircle, contentDescription = "Not controlled by this app", tint = SecondaryText)
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                "DualSound can play your music in the background. Separate audio for other apps depends on your phone's system features.",
                color = SecondaryText,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}

private fun checkBluetoothOutput(context: Context): Boolean {
    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    return audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { device ->
        device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            device.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
            device.type == AudioDeviceInfo.TYPE_BLE_SPEAKER
    }
}

private fun fileTitle(context: Context, uri: Uri): String {
    val projection = arrayOf(android.provider.OpenableColumns.DISPLAY_NAME)
    context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) {
            val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0) return cursor.getString(index).substringBeforeLast('.', cursor.getString(index))
        }
    }
    return uri.lastPathSegment?.substringAfterLast('/') ?: "Selected audio"
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
