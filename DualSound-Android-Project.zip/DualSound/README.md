# DualSound (Android starter)

A starter Android Studio project for a Kotlin + Jetpack Compose music player using AndroidX Media3.

## Open and run
1. Install Android Studio.
2. Open the `DualSound` folder in Android Studio.
3. Allow Gradle to sync and install any requested Android SDK components (compile SDK 35).
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press Run.
6. Tap the folder icon / **Choose music from phone** and select one or more audio files.

## Main files
- `app/src/main/java/com/example/dualsound/MainActivity.kt` — player screen, audio picker, transport controls, progress and Bluetooth output status.
- `app/src/main/java/com/example/dualsound/MusicPlaybackService.kt` — Media3 playback service for background playback.
- `app/src/main/AndroidManifest.xml` — activity and media playback service declarations.
- `app/build.gradle.kts` — Compose and Media3 dependencies.

## Important limitations
- The Bluetooth status indicates that a Bluetooth audio output device is connected/available; it does not prove that the current player is routed to that device in every OEM configuration.
- Android does not provide a normal public API that lets this app force arbitrary third-party apps (YouTube, WhatsApp, browsers, etc.) to play through the phone speaker while this app's music plays over Bluetooth. Use a manufacturer feature such as Samsung Separate app sound when available.
- This is a starter source project, not a prebuilt APK. Gradle sync/build should be performed in Android Studio on a machine with the Android SDK installed.
